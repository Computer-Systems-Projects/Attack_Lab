/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_482()
{
    return 3347662849U;
}

unsigned addval_384(unsigned x)
{
    return x + 3267856712U;
}

void setval_215(unsigned *p)
{
    *p = 1489535984U;
}

unsigned addval_484(unsigned x)
{
    return x + 3344485382U;
}

unsigned getval_407()
{
    return 3347662940U;
}

unsigned addval_311(unsigned x)
{
    return x + 1476484738U;
}

unsigned getval_431()
{
    return 3260549235U;
}

unsigned getval_458()
{
    return 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_175(unsigned *p)
{
    *p = 3677935305U;
}

unsigned addval_189(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_158(unsigned x)
{
    return x + 3224945025U;
}

void setval_340(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_480(unsigned x)
{
    return x + 3523789193U;
}

unsigned addval_446(unsigned x)
{
    return x + 3374372491U;
}

void setval_362(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_238(unsigned x)
{
    return x + 3398279468U;
}

unsigned getval_291()
{
    return 3525362121U;
}

unsigned addval_108(unsigned x)
{
    return x + 3674789505U;
}

void setval_461(unsigned *p)
{
    *p = 3286272330U;
}

void setval_286(unsigned *p)
{
    *p = 3251276072U;
}

unsigned addval_469(unsigned x)
{
    return x + 3375945353U;
}

unsigned addval_371(unsigned x)
{
    return x + 2445379901U;
}

unsigned getval_161()
{
    return 2464188744U;
}

void setval_456(unsigned *p)
{
    *p = 3286276424U;
}

unsigned getval_144()
{
    return 3269495112U;
}

void setval_165(unsigned *p)
{
    *p = 3682915976U;
}

unsigned getval_499()
{
    return 3281046152U;
}

unsigned getval_116()
{
    return 3525367433U;
}

unsigned addval_485(unsigned x)
{
    return x + 3674789545U;
}

unsigned getval_135()
{
    return 3531917961U;
}

unsigned addval_410(unsigned x)
{
    return x + 2430634316U;
}

void setval_487(unsigned *p)
{
    *p = 3525364353U;
}

unsigned addval_422(unsigned x)
{
    return x + 3682912905U;
}

unsigned getval_421()
{
    return 3523270281U;
}

void setval_345(unsigned *p)
{
    *p = 3526937229U;
}

unsigned addval_239(unsigned x)
{
    return x + 3524840073U;
}

unsigned getval_282()
{
    return 2425405897U;
}

unsigned addval_167(unsigned x)
{
    return x + 3674784201U;
}

unsigned getval_196()
{
    return 3284240643U;
}

unsigned addval_432(unsigned x)
{
    return x + 3281174921U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
